Birthday Manager - JavaFX + JDBC + MySQL
=======================================
Instructions (সংক্ষিপ্ত নির্দেশনাবলী)
1. MySQL এ ডাটাবেস তৈরি:
   - MySQL এ লগইন করে নিম্নলিখিত SQL চালাও:
     CREATE DATABASE birthday_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
     USE birthday_db;
     -- টেবিল তৈরি
     CREATE TABLE classmates (
       id INT AUTO_INCREMENT PRIMARY KEY,
       name VARCHAR(200) NOT NULL,
       dob DATE NOT NULL,
       notes TEXT
     );
2. db.properties ফাইলে MySQL credentials ঠিক করো (user, password, url)
3. Java 11+ এবং JavaFX SDK লাগবে। IDE (IntelliJ/Eclipse) ব্যবহার করো।
4. Maven/Gradle প্রোজেক্টে JavaFX এবং MySQL Connector যোগ করো। এই ফোল্ডারের কোডগুলো src/main/java হিসাবে রূপান্তর করে ব্যবহার করতে পারো।
5. রান: MainApp.java চালিয়ে প্রোগ্রাম শুরু করো।

বৈশিষ্ট্য (Features)
- যোগ (Add), আপডেট (Update), মুছুন (Delete)
- আসন্ন জন্মদিন ছকে দেখাবে (Upcoming, sort by date)
- নাম বা মাস অনুযায়ী সার্চ (Search by Name or Month)
- আজকের জন্মদিনের নোটিফিকেশন (Notification on startup)

ফাইল তালিকা:
- src/... (Java ও FXML কোড)
- db.properties (JDBC settings)
- schema.sql (DB schema)

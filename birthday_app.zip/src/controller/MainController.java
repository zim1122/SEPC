import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class MainController {

    @FXML private TableView<Birthday> table;
    @FXML private TableColumn<Birthday, Integer> colId;
    @FXML private TableColumn<Birthday, String> colName;
    @FXML private TableColumn<Birthday, String> colDob;
    @FXML private TableColumn<Birthday, String> colNotes;

    @FXML private TextField tfName;
    @FXML private DatePicker dpDob;
    @FXML private TextField tfNotes;
    @FXML private TextField tfSearch;
    @FXML private ComboBox<String> cbMonth;

    @FXML private Button btnAdd;
    @FXML private Button btnUpdate;
    @FXML private Button btnDelete;
    @FXML private Button btnSearch;
    @FXML private Button btnRefresh;

    private BirthdayDAO dao = new BirthdayDAO();
    private ObservableList<Birthday> data = FXCollections.observableArrayList();

    private DateTimeFormatter df = DateTimeFormatter.ofPattern("d MMM yyyy");

    @FXML
    public void initialize() {
        colId.setCellValueFactory(cell -> javafx.beans.property.SimpleIntegerProperty.integerProperty(new javafx.beans.property.SimpleIntegerProperty(cell.getValue().getId())).asObject());
        colName.setCellValueFactory(cell -> new javafx.beans.property.SimpleStringProperty(cell.getValue().getName()));
        colDob.setCellValueFactory(cell -> new javafx.beans.property.SimpleStringProperty(cell.getValue().getDob().format(df)));
        colNotes.setCellValueFactory(cell -> new javafx.beans.property.SimpleStringProperty(cell.getValue().getNotes()));

        // months
        cbMonth.getItems().add("--- মাস নির্বাচন করুন ---");
        for (int i = 1; i <= 12; i++) {
            cbMonth.getItems().add(String.valueOf(i));
        }
        cbMonth.getSelectionModel().selectFirst();

        table.setItems(data);
        refreshTable();
    }

    public void refreshTable() {
        Platform.runLater(() -> {
            try {
                List<Birthday> list = dao.getAll();
                data.setAll(list);
            } catch (Exception e) {
                showError(e);
            }
        });
    }

    @FXML
    public void onAdd(ActionEvent e) {
        try {
            String name = tfName.getText().trim();
            LocalDate dob = dpDob.getValue();
            String notes = tfNotes.getText().trim();
            if (name.isEmpty() || dob == null) {
                showAlert("তথ্য অসম্পূর্ণ", "নাম ও জন্মতারিখ অবশ্যই দিতে হবে।", Alert.AlertType.WARNING);
                return;
            }
            Birthday b = new Birthday(name, dob, notes);
            dao.insert(b);
            refreshTable();
            clearForm();
        } catch (Exception ex) {
            showError(ex);
        }
    }

    @FXML
    public void onUpdate(ActionEvent e) {
        Birthday sel = table.getSelectionModel().getSelectedItem();
        if (sel == null) {
            showAlert("নির্বাচিত নেই", "আপনি কোনো রেকর্ড সিলেক্ট করেননি।", Alert.AlertType.WARNING);
            return;
        }
        try {
            sel.setName(tfName.getText().trim());
            sel.setDob(dpDob.getValue());
            sel.setNotes(tfNotes.getText().trim());
            dao.update(sel);
            refreshTable();
            clearForm();
        } catch (Exception ex) {
            showError(ex);
        }
    }

    @FXML
    public void onDelete(ActionEvent e) {
        Birthday sel = table.getSelectionModel().getSelectedItem();
        if (sel == null) {
            showAlert("নির্বাচিত নেই", "আপনি কোনো রেকর্ড সিলেক্ট করেননি।", Alert.AlertType.WARNING);
            return;
        }
        Alert a = new Alert(Alert.AlertType.CONFIRMATION);
        a.setTitle("নিশ্চিতকরণ");
        a.setHeaderText("মুছতে চান?");
        a.setContentText("নাম: " + sel.getName());
        var res = a.showAndWait();
        if (res.isPresent() && res.get() == ButtonType.OK) {
            try {
                dao.delete(sel.getId());
                refreshTable();
                clearForm();
            } catch (Exception ex) {
                showError(ex);
            }
        }
    }

    @FXML
    public void onSearch(ActionEvent e) {
        String txt = tfSearch.getText().trim();
        String month = cbMonth.getSelectionModel().getSelectedItem();
        try {
            if (!txt.isEmpty()) {
                data.setAll(dao.searchByName(txt));
            } else if (month != null && !month.startsWith("-")) {
                data.setAll(dao.searchByMonth(Integer.parseInt(month)));
            } else {
                refreshTable();
            }
        } catch (Exception ex) {
            showError(ex);
        }
    }

    @FXML
    public void onRefresh(ActionEvent e) {
        refreshTable();
    }

    @FXML
    public void onTableClick(MouseEvent e) {
        Birthday sel = table.getSelectionModel().getSelectedItem();
        if (sel != null) {
            tfName.setText(sel.getName());
            dpDob.setValue(sel.getDob());
            tfNotes.setText(sel.getNotes());
        }
    }

    public void checkTodaysBirthdays() {
        Platform.runLater(() -> {
            try {
                List<Birthday> list = dao.todaysBirthdays();
                if (!list.isEmpty()) {
                    StringBuilder sb = new StringBuilder();
                    for (Birthday b : list) {
                        sb.append(b.getName()).append(" — ").append(b.getDob().getYear()).append("").append("\n");
                    }
                    showAlert("আজকের জন্মদিন", sb.toString(), Alert.AlertType.INFORMATION);
                }
            } catch (Exception e) {
                showError(e);
            }
        });
    }

    private void clearForm() {
        tfName.clear();
        dpDob.setValue(null);
        tfNotes.clear();
        table.getSelectionModel().clearSelection();
    }

    private void showAlert(String title, String content, Alert.AlertType t) {
        Alert a = new Alert(t);
        a.setTitle(title);
        a.setHeaderText(null);
        a.setContentText(content);
        a.showAndWait();
    }

    private void showError(Exception e) {
        e.printStackTrace();
        showAlert("ত্রুটি", e.getMessage(), Alert.AlertType.ERROR);
    }
}

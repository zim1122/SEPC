import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.ResourceBundle;

public class MainApp extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        // Use default Locale or force Bengali locale for date formatting
        Locale.setDefault(new Locale("bn", "BD"));
        ResourceBundle bundle = ResourceBundle.getBundle("bundles.labels");

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/main.fxml"), bundle);
        Parent root = loader.load();
        primaryStage.setTitle(bundle.getString("app.title"));
        primaryStage.setScene(new Scene(root, 800, 500));
        primaryStage.show();

        // After showing, call controller to show today's birthdays
        var controller = loader.getController();
        controller.checkTodaysBirthdays();
    }

    public static void main(String[] args) {
        launch(args);
    }
}

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class BirthdayDAO {

    public List<Birthday> getAll() throws Exception {
        List<Birthday> list = new ArrayList<>();
        String sql = "SELECT id, name, dob, notes FROM classmates ORDER BY MONTH(dob), DAY(dob)";
        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(new Birthday(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getDate("dob").toLocalDate(),
                        rs.getString("notes")
                ));
            }
        }
        return list;
    }

    public List<Birthday> searchByName(String name) throws Exception {
        List<Birthday> list = new ArrayList<>();
        String sql = "SELECT id, name, dob, notes FROM classmates WHERE name LIKE ? ORDER BY MONTH(dob), DAY(dob)";
        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, "%" + name + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new Birthday(
                            rs.getInt("id"),
                            rs.getString("name"),
                            rs.getDate("dob").toLocalDate(),
                            rs.getString("notes")
                    ));
                }
            }
        }
        return list;
    }

    public List<Birthday> searchByMonth(int month) throws Exception {
        List<Birthday> list = new ArrayList<>();
        String sql = "SELECT id, name, dob, notes FROM classmates WHERE MONTH(dob)=? ORDER BY DAY(dob)";
        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, month);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new Birthday(
                            rs.getInt("id"),
                            rs.getString("name"),
                            rs.getDate("dob").toLocalDate(),
                            rs.getString("notes")
                    ));
                }
            }
        }
        return list;
    }

    public Birthday insert(Birthday b) throws Exception {
        String sql = "INSERT INTO classmates (name, dob, notes) VALUES (?, ?, ?)";
        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, b.getName());
            ps.setDate(2, Date.valueOf(b.getDob()));
            ps.setString(3, b.getNotes());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    b.setId(keys.getInt(1));
                }
            }
        }
        return b;
    }

    public void update(Birthday b) throws Exception {
        String sql = "UPDATE classmates SET name=?, dob=?, notes=? WHERE id=?";
        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, b.getName());
            ps.setDate(2, Date.valueOf(b.getDob()));
            ps.setString(3, b.getNotes());
            ps.setInt(4, b.getId());
            ps.executeUpdate();
        }
    }

    public void delete(int id) throws Exception {
        String sql = "DELETE FROM classmates WHERE id=?";
        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    public List<Birthday> todaysBirthdays() throws Exception {
        List<Birthday> list = new ArrayList<>();
        String sql = "SELECT id, name, dob, notes FROM classmates WHERE MONTH(dob)=? AND DAY(dob)=?";
        LocalDate today = LocalDate.now();
        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, today.getMonthValue());
            ps.setInt(2, today.getDayOfMonth());
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new Birthday(
                            rs.getInt("id"),
                            rs.getString("name"),
                            rs.getDate("dob").toLocalDate(),
                            rs.getString("notes")
                    ));
                }
            }
        }
        return list;
    }
}

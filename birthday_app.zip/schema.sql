CREATE DATABASE IF NOT EXISTS birthday_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE birthday_db;
CREATE TABLE IF NOT EXISTS classmates (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(200) NOT NULL,
  dob DATE NOT NULL,
  notes TEXT
);
INSERT INTO classmates (name, dob, notes) VALUES
  ('রহিম', '2000-12-31', 'Classmate from CSE'),
  ('করিম', '2001-01-05', 'Likes football'),
  ('সাবরিনা', '2000-11-28', 'Class rep');

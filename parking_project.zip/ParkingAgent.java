public class ParkingAgent extends Thread {

    private ParkingPool pool;

    public ParkingAgent(ParkingPool pool, String name) {
        super(name);
        this.pool = pool;
    }

    @Override
    public void run() {
        while (true) {
            try {
                String car = pool.getCar();
                System.out.println(getName() + " is parking Car: " + car);
                Thread.sleep(1000);
                System.out.println(getName() + ": Finished parking " + car);
            } catch (InterruptedException e) {
                System.out.println(getName() + " stopped.");
                return;
            }
        }
    }
}
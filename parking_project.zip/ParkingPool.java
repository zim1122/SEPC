import java.util.LinkedList;
import java.util.Queue;

public class ParkingPool {

    private Queue<String> queue = new LinkedList<>();

    public synchronized void addCar(String car) {
        queue.add(car);
        System.out.println("ParkingPool: Car added -> " + car);
        notify();
    }

    public synchronized String getCar() throws InterruptedException {
        while (queue.isEmpty()) {
            wait();
        }
        return queue.poll();
    }
}
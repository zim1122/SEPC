public class MainClass {

    public static void main(String[] args) throws InterruptedException {

        ParkingPool pool = new ParkingPool();
        RegistrarParking registrar = new RegistrarParking(pool);

        ParkingAgent a1 = new ParkingAgent(pool, "Agent-1");
        ParkingAgent a2 = new ParkingAgent(pool, "Agent-2");

        a1.start();
        a2.start();

        for (int i = 1; i <= 10; i++) {
            registrar.registerCar("CAR-" + i);
            Thread.sleep(500);
        }

        Thread.sleep(5000);
        a1.interrupt();
        a2.interrupt();
    }
}
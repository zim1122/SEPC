public class RegistrarParking {

    private ParkingPool pool;

    public RegistrarParking(ParkingPool pool) {
        this.pool = pool;
    }

    public void registerCar(String carNumber) {
        System.out.println("Registrar: Received parking request for Car " + carNumber);
        pool.addCar(carNumber);
    }
}
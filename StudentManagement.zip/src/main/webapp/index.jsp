
<html><body>
<h2>Add Student</h2>
<form action="add" method="post">
<input name="name"><br>
<input name="email"><br>
<button>Save</button>
</form>
<a href="list">View</a>
</body></html>


<%@ page import="java.util.*,model.Student"%>
<table border="1">
<%
for(Student s:(List<Student>)request.getAttribute("students")){
%>
<tr>
<td><%=s.getId()%></td>
<td><%=s.getName()%></td>
<td><%=s.getEmail()%></td>
<td><a href="delete?id=<%=s.getId()%>">Delete</a></td>
</tr>
<%}%>
</table>


package servlet;
import dao.StudentDAO;
import model.Student;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;

public class AddStudentServlet extends HttpServlet{
    protected void doPost(HttpServletRequest r,HttpServletResponse s)throws ServletException,IOException{
        new StudentDAO().insert(new Student(r.getParameter("name"),r.getParameter("email")));
        s.sendRedirect("list");
    }
}

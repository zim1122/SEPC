
package servlet;
import dao.StudentDAO;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;

public class ListStudentServlet extends HttpServlet{
    protected void doGet(HttpServletRequest r,HttpServletResponse s)throws ServletException,IOException{
        r.setAttribute("students",new StudentDAO().all());
        r.getRequestDispatcher("students.jsp").forward(r,s);
    }
}

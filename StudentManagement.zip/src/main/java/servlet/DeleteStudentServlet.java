
package servlet;
import dao.StudentDAO;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;

public class DeleteStudentServlet extends HttpServlet{
    protected void doGet(HttpServletRequest r,HttpServletResponse s)throws ServletException,IOException{
        new StudentDAO().delete(Integer.parseInt(r.getParameter("id")));
        s.sendRedirect("list");
    }
}

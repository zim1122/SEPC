
package dao;
import java.sql.*;
import java.util.*;
import model.Student;

public class StudentDAO {
    String url="jdbc:mysql://localhost:3306/student_db";
    String user="root";
    String pass="";
    Connection getCon() throws Exception{
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(url,user,pass);
    }
    public void insert(Student s){
        try(Connection c=getCon()){
            PreparedStatement p=c.prepareStatement("insert into student(name,email) values(?,?)");
            p.setString(1,s.getName());
            p.setString(2,s.getEmail());
            p.execute();
        }catch(Exception e){}
    }
    public List<Student> all(){
        List<Student> l=new ArrayList<>();
        try(Connection c=getCon()){
            ResultSet r=c.createStatement().executeQuery("select * from student");
            while(r.next()){
                Student s=new Student();
                s.setId(r.getInt("id"));
                s.setName(r.getString("name"));
                s.setEmail(r.getString("email"));
                l.add(s);
            }
        }catch(Exception e){}
        return l;
    }
    public void delete(int id){
        try(Connection c=getCon()){
            PreparedStatement p=c.prepareStatement("delete from student where id=?");
            p.setInt(1,id);
            p.execute();
        }catch(Exception e){}
    }
}

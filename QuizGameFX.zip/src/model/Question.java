
package model;

public class Question {
    public String q,a,b,c,d,ans;
    public Question(String q,String a,String b,String c,String d,String ans){
        this.q=q; this.a=a; this.b=b; this.c=c; this.d=d; this.ans=ans;
    }
}

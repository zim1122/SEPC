
package db;
import java.sql.*;

public class DB {
    static String url="jdbc:mysql://localhost:3306/quiz_db";
    static String user="root";
    static String pass="";

    public static ResultSet getQuestions() throws Exception{
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection c = DriverManager.getConnection(url,user,pass);
        return c.createStatement().executeQuery("select * from question");
    }
}

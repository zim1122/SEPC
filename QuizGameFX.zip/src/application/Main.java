
package application;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import db.DB;
import model.Question;
import java.sql.ResultSet;

public class Main extends Application {
    int score = 0;
    int index = 0;
    Question[] questions = new Question[10];

    @Override
    public void start(Stage stage) throws Exception {
        ResultSet rs = DB.getQuestions();
        int i = 0;
        while(rs.next()){
            questions[i++] = new Question(
                rs.getString("question"),
                rs.getString("a"),
                rs.getString("b"),
                rs.getString("c"),
                rs.getString("d"),
                rs.getString("ans")
            );
        }

        Label q = new Label();
        RadioButton r1 = new RadioButton();
        RadioButton r2 = new RadioButton();
        RadioButton r3 = new RadioButton();
        RadioButton r4 = new RadioButton();
        ToggleGroup tg = new ToggleGroup();
        r1.setToggleGroup(tg); r2.setToggleGroup(tg);
        r3.setToggleGroup(tg); r4.setToggleGroup(tg);

        Button next = new Button("Next");

        load(q, r1, r2, r3, r4);

        next.setOnAction(e -> {
            RadioButton sel = (RadioButton) tg.getSelectedToggle();
            if(sel != null && sel.getText().equals(questions[index].ans)) score++;
            index++;
            if(index < questions.length) load(q,r1,r2,r3,r4);
            else q.setText("Quiz Finished! Score: " + score);
        });

        VBox root = new VBox(10, q, r1, r2, r3, r4, next);
        stage.setScene(new Scene(root, 400, 300));
        stage.setTitle("Quiz Game");
        stage.show();
    }

    void load(Label q, RadioButton r1, RadioButton r2, RadioButton r3, RadioButton r4){
        Question qu = questions[index];
        q.setText(qu.q);
        r1.setText(qu.a);
        r2.setText(qu.b);
        r3.setText(qu.c);
        r4.setText(qu.d);
    }

    public static void main(String[] args) {
        launch();
    }
}

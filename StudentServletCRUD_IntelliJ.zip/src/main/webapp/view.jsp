<%@ page import="java.util.*,model.Student" %>
<h2>Action: View</h2>
<table border="1">
<tr><th>Name</th><th>Email</th></tr>
<%
List<Student> list = (List<Student>)request.getAttribute("list");
for(Student s:list){
%>
<tr><td><%=s.getName()%></td><td><%=s.getEmail()%></td></tr>
<% } %>
</table>

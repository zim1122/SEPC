<!DOCTYPE html>
<html>
<head><title>Student CRUD</title></head>
<body>
<h1>Enter Student Details</h1>
<form action="student" method="post">
Name: <input type="text" name="name"><br><br>
Email: <input type="email" name="email"><br><br>
<button type="submit" name="action" value="insert">Insert</button>
<button type="submit" name="action" value="view">View</button>
<button type="submit" name="action" value="update">Update</button>
<button type="submit" name="action" value="delete">Delete</button>
</form>
</body>
</html>

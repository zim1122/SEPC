package dao;
import java.sql.*;
import java.util.*;
import model.Student;
public class StudentDAO {
    Connection getConnection() throws Exception{
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(
        "jdbc:mysql://localhost:3306/studentdb","root","");
    }
    public void insert(String n,String e)throws Exception{
        Connection c=getConnection();
        PreparedStatement p=c.prepareStatement(
        "insert into student(name,email) values(?,?)");
        p.setString(1,n); p.setString(2,e);
        p.executeUpdate(); c.close();
    }
    public List<Student> view()throws Exception{
        List<Student> l=new ArrayList<>();
        Connection c=getConnection();
        ResultSet r=c.createStatement()
        .executeQuery("select * from student");
        while(r.next()){
            l.add(new Student(r.getString("name"),
                              r.getString("email")));
        }
        c.close(); return l;
    }
    public void delete(String e)throws Exception{
        Connection c=getConnection();
        PreparedStatement p=c.prepareStatement(
        "delete from student where email=?");
        p.setString(1,e); p.executeUpdate(); c.close();
    }
    public void update(String n,String e)throws Exception{
        Connection c=getConnection();
        PreparedStatement p=c.prepareStatement(
        "update student set name=? where email=?");
        p.setString(1,n); p.setString(2,e);
        p.executeUpdate(); c.close();
    }
}

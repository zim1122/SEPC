package controller;
import dao.StudentDAO;
import model.Student;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.*;
public class StudentServlet extends HttpServlet{
protected void doPost(HttpServletRequest r,HttpServletResponse s)
throws ServletException,IOException{
String a=r.getParameter("action");
String n=r.getParameter("name");
String e=r.getParameter("email");
StudentDAO d=new StudentDAO();
try{
if(a.equals("insert")){ d.insert(n,e); s.sendRedirect("index.jsp"); }
else if(a.equals("view")){
List<Student> l=d.view();
r.setAttribute("list",l);
r.getRequestDispatcher("view.jsp").forward(r,s);
}
else if(a.equals("delete")){ d.delete(e); s.sendRedirect("index.jsp"); }
else if(a.equals("update")){ d.update(n,e); s.sendRedirect("index.jsp"); }
}catch(Exception ex){ex.printStackTrace();}
}
}
